#include <stdio.h>


int main (){
    int n , maior , menor, contador = 0;

    
    printf("Digite o valor do n1\n");
    scanf("%d" , &n1);

    if(num != 0){
        maior = num;
        menor = num;

        contador ++;
    }

    while(n1 != 0){        

        switch(comparar){
            case 0:
            printf("Programa encerrado")
            break;

            default:

            if(n1 > maior){
                maior > numero;
            }
            
            break;
        }
    }
}