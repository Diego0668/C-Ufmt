#include <stdio.h>

int main (){
    int i;

    for(i = 0; i <= 10; i++){
        printf("%d\n" , i);
    }
    printf("Metade do caminho percorrida!");
    for(i > 10; i <= 20; i++){
        printf("%d\n" , i);
    }
    

}